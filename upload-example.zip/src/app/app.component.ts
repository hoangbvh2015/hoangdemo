import { Component, ElementRef, ViewChild } from '@angular/core';
import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'Angular';

  @ViewChild('file', { read: ElementRef })
  file: ElementRef;

  constructor(private http: HttpClient) { }

  upload() {
    const files = (this.file.nativeElement as HTMLInputElement).files;

    const sendable = new FormData();
    sendable.append('documentTypeId', '302');

    let groups =  
      [{
        "typeId":"0",
        "instanceId":1,
      "keywords":[
        {"typeId":"1","value":"Test"},{"typeId":"290","value":""},{"typeId":"291","value":""},{"typeId":"121","value":""},{"typeId":"330","value":""},{"typeId":"237","value":""}
        ]
      }
      ];
      
      console.log(groups);
    sendable.append('keywordGroups', JSON.stringify(groups));
    for (let i = 0; i < files.length; i++) {
      sendable.append('files', files[i], files[i].name);
    }

    const request = new HttpRequest('POST',
      'https://localhost:5001/api/upload',
      sendable,
      {
        reportProgress: true
      });

    this.http.request(request)
      .subscribe((event: any) => {
        if (event.type === HttpEventType.UploadProgress) {
          // on progress code
        }
        if (event.type === HttpEventType.Response) {
          console.log(event);
          // on response code
        }
      }, error => {
        // on error code
      });
  }
}
